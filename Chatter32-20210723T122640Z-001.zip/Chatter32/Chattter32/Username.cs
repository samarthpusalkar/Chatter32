﻿using System;
using System.Net.Mail;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Chattter32
{
	public partial class Username2 : Form
	{
		public Username2()
		{
			InitializeComponent();
		}
		void RegiClick(object sender, System.EventArgs e)
		{
			String Username = username.Text;
			String Email = email.Text;
			String email11 = Email.Replace(" ",string.Empty);
			try{if(email11=="")
			{
				MessageBox.Show("Please Fill The Required Field(s).");
			}else{
			string connectionString = "Data Source=db4free.net;Initial Catalog=database;User ID=username;Password=password";
			MySqlConnection cnn = new MySqlConnection(connectionString);
			cnn.Close();
			cnn.Open();
			MySqlCommand cmd = new MySqlCommand();
			cmd.CommandText = "select COALESCE(sum(ID),0) from user where email = '"+Email+"';";
			cmd.Connection = cnn;
			decimal checkemail =(decimal)cmd.ExecuteScalar();
			cnn.Close();
				if(checkemail!=0)
				{
					incerter();
				}
			}
		}catch
			{
				MessageBox.Show("Error while processing. Make sure you are connected to the internet.");
			}
		}
		public void incerter()
		{
			Random rnd = new Random();
			int random = rnd.Next(1, 1000);
			String code = random.ToString();
			String Username = username.Text;
			String Email = email.Text;
			try{
			String emailbody = "Your Account Details are :"+System.Environment.NewLine+"Reset Username Code : "+code+"";
			MailMessage mail = new MailMessage("noreply@chatter32.tk", ""+Email+"", "Reset Code for Chatter32 Account", emailbody);
			SmtpClient client = new SmtpClient("smtp.gmail.com");
			client.Port = 587;	
			client.Credentials = new System.Net.NetworkCredential("email@gmail.com","password");
			client.EnableSsl = true;
			client.Send(mail);
			string connectionString = "Data Source=db4free.net;Initial Catalog=database;User ID=username;Password=password";
			MySqlConnection cnn = new MySqlConnection(connectionString);
			cnn.Open();
			MySqlCommand cmd1 = new MySqlCommand();
			cmd1.CommandText = "UPDATE `user` SET `username`='"+code+"' WHERE email = '"+Email+"';";
			cmd1.Connection = cnn;
			MySqlDataReader reader = cmd1.ExecuteReader();
			MessageBox.Show("Sending Code To Email.");
			MessageBox.Show("Email Send! Check mail for Reset Code.");
				email.Text="";
			}
			catch{
				MessageBox.Show("Error while processing. Make sure you are connected to the internet.");
			}finally
			{
				username.Text="";
				email1.Text="";
				code1.Text="";
			}
			
		}
		void VeriClick(object sender, System.EventArgs e)
		{
			String Username = username.Text;
			String Email = email1.Text;
			String code = code1.Text;
			try{
			string connectionString = "Data Source=db4free.net;Initial Catalog=database;User ID=username;Password=password";
			MySqlConnection cnn = new MySqlConnection(connectionString);
			cnn.Open();
			MySqlCommand cmd = new MySqlCommand();
			MySqlCommand cmd0 = new MySqlCommand();
			MySqlCommand cmd1 = new MySqlCommand();
			cmd.CommandText = "select COALESCE(sum(ID),0) from user where email = '"+Email+"';";
			cmd0.CommandText="select username from `user` WHERE email = '"+Email+"';";
			cmd1.CommandText = "UPDATE `user` SET `username`='"+Username+"' WHERE email = '"+Email+"';";
			cmd.Connection = cnn;
			cmd1.Connection = cnn;
			cmd0.Connection = cnn;
			decimal detectcode = ((decimal)cmd.ExecuteScalar());
			if (detectcode !=0)
			{
				String detectusername = (String)cmd0.ExecuteScalar().ToString();
				if(detectusername==code)
				{
					cmd1.ExecuteScalar();
					MessageBox.Show("Username Reseted." +
						System.Environment.NewLine +
						"Account Ready for use !");
					this.Close();
				}else
				{
					MessageBox.Show("Invalid Code !");
					email1.Text="";
					username.Text="";
				}
			}else
			{
				MessageBox.Show("Email doesn't exist.");
				email1.Text="";
					username.Text="";
					cnn.Close();
				}
			}catch
			{
				MessageBox.Show("Error while processing.. Make sure that you are connected to the internet.");
			}
		}
	}
}
