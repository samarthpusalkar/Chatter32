﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Linq;
using MySql.Data.MySqlClient;

namespace Chattter32
{
	public partial class MainFor : Form
	{
		Form opener;
		String Group;
		public MainFor(Form parentForm, String name1,String Group1)
		{
			InitializeComponent();
			opener = parentForm;
			Group=Group1;
			string connectionString = "Data Source=db4free.net;Initial Catalog=database;User ID=username;Password=password";
            MySqlConnection cnn = new MySqlConnection(connectionString);
            try
            {
                cnn.Open();
                MessageBox.Show("Connection Open ! ");			
            }
            catch
            {
                MessageBox.Show("Can not open connection ! Make Sure You Are Connected To Internet !");
				opener.Close();
				this.Close();
            }
            finally
            {
                cnn.Close();
            }
				cnn.Close();
			
			name.Text = name1;
			Refresher();
		}
		protected override void OnFormClosing(FormClosingEventArgs e)
		{
    		Application.Exit();
		}
		void EntClick(object sender, System.EventArgs e)
		{
			string connectionString = "Data Source=db4free.net;Initial Catalog=database;User ID=username;Password=password";
			MySqlConnection cnn = new MySqlConnection(connectionString);
			MySqlCommand cmd = new MySqlCommand();
			cnn.Open();
			cmd.CommandText = "Select Output from chating where group1='"+Group+"';";
			cmd.CommandType = CommandType.Text;
			cmd.Connection = cnn;
			String result = ((String)cmd.ExecuteScalar());
			End(result);
		}
		void End(String Resul)
		{
			String input = Input.Text.ToString();
			String oot = Resul.ToString();
			String output = name.Text+" : "+input +System.Environment.NewLine+System.Environment.NewLine+oot+System.Environment.NewLine+System.Environment.NewLine;
			Out.Text = output;
			Input.Text="";			 
			string connectionString = "Data Source=db4free.net;Initial Catalog=database;User ID=username;Password=password";
			MySqlConnection cnn = new MySqlConnection(connectionString);
			MySqlCommand cmd = new MySqlCommand();
			cnn.Open();
			MySqlDataReader ready;
			cmd.CommandText = "UPDATE chating SET Input = '"+input+"', Output = '"+output+"' WHERE group1 = '"+Group+"';";
			cmd.CommandType = CommandType.Text;
			cmd.Connection = cnn;
			ready = cmd.ExecuteReader();
			
		}
		void ExitClick(object sender, System.EventArgs e)
		{
			Exi();
		}

		void Exi()
		{
			opener.Close();

			this.Close();
		}
		void RefreshClick(object sender, System.EventArgs e)
		{
			Refresher();
		}
		void Refresher()
		{
			string connectionString = "Data Source=db4free.net;Initial Catalog=database name;User ID=username;Password=password";
            MySqlConnection cnn = new MySqlConnection(connectionString);
			MySqlCommand cmd = new MySqlCommand();
			cnn.Open();
			cmd.CommandText = "Select Output from chating where group1='"+Group+"';";
			cmd.CommandType = CommandType.Text;
			cmd.Connection = cnn;
			String output1 = ((String)cmd.ExecuteScalar());
			Out.Text=output1;			
			cnn.Close();
		}	
	}
	
}