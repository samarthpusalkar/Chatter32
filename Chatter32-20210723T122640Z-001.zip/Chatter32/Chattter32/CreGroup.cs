﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Chattter32
{
	public partial class CreGroup : Form
	{
		string connectionString = "SERVER=server;PORT=3306;DATABASE=database name;UID=username;PWD=password";
		MySqlConnection cnn;
		public CreGroup()
		{
			InitializeComponent();
			cnn = new MySqlConnection(connectionString);
			password.PasswordChar='*';
		}
		void CreGrouClick(object sender, System.EventArgs e)
		{
			try{cnn.Open();} catch  (Exception e1){MessageBox.Show(e1.ToString());}
			String Group = group.Text;
			String Password = password.Text;
			if(Group==""||Password==""){MessageBox.Show("Please fill both the fields");}else{
			MySqlCommand cmd = new MySqlCommand();
			MySqlCommand cmd1 = new MySqlCommand();
			cmd.CommandText = "select COALESCE(sum(ID),0) from chating where group1 = '"+Group+"';";
			cmd1.CommandText="INSERT INTO `chating`(`Input`, `Output`,`password`, `group1`) VALUES ('','','"+Password+"','"+Group+"');";
			cmd.Connection = cnn;
			cmd1.Connection = cnn;
			decimal check =(decimal)cmd.ExecuteScalar();
			if(check==0)
			{
				cmd1.ExecuteScalar();
				MessageBox.Show("Group Created successfully.");
				this.Close();
			}else{MessageBox.Show("Group Name already exist please try another.");}}
			cnn.Close();
		}
	}
}
