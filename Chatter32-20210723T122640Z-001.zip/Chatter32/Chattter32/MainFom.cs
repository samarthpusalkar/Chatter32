﻿using System;
using System.Net.Mail;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Chattter32;

namespace Chattter32
{
	public partial class MainFom : Form
	{
		public MainFom()
		{
			InitializeComponent();
			gropass.PasswordChar='*';
			password.PasswordChar='*';
		}
		void RegiClick(object sender, System.EventArgs e)
		{
			String Username = username.Text;
			String Email = email.Text;
			String username11 = Username.Replace(" ",string.Empty);
			String email11 = Email.Replace(" ",string.Empty);
			String Group=group.Text;
			String GroPass=gropass.Text;
			if(username11=="" || email11=="" || group.Text==""||gropass.Text=="")
			{
				MessageBox.Show("Please Fill The Required Fields.");
			}else{
			string connectionString = "Data Source=db4free.net;Initial Catalog=database;User ID=username;Password=password";
			MySqlConnection cnn = new MySqlConnection(connectionString);
			try
            {
                cnn.Open();
            }
            catch (Exception)
            {
                MessageBox.Show("Can not open connection ! Make Sure You Are Connected To Internet !");
				this.Close();
				Close();
            }
            finally
            {
                cnn.Close();
            }
			cnn.Close();
			cnn.Open();
			MySqlCommand cmd = new MySqlCommand();
				MySqlCommand cmd0=new MySqlCommand();
			MySqlCommand cmd1 = new MySqlCommand();
				MySqlCommand cmd2 = new MySqlCommand();
			cmd.CommandText = "select COALESCE(sum(ID),0) from user where username = '"+Username+"';";
				cmd0.CommandText="select COALESCE(sum(ID),0) from chating where group1 = '"+Group+"';";
			cmd1.CommandText = "select COALESCE(sum(ID),0) from user where email = '"+Email+"';";
				cmd2.CommandText="select password from chating where group1 ='"+Group+"';";
			cmd.Connection = cnn;
				cmd0.Connection=cnn;
			cmd1.Connection = cnn;
				cmd2.Connection=cnn;
			decimal checkuser = (decimal)cmd.ExecuteScalar();
			decimal checkemail =(decimal)cmd1.ExecuteScalar();
				decimal checkgroup =(decimal)cmd0.ExecuteScalar();
			if(checkuser == 0)
			{
				if(checkemail ==0)
				{
						if(checkgroup!=0)
						{
							String gropassw = ((String)cmd2.ExecuteScalar());
							if(gropassw == GroPass){
								incerter(Group);
							}else{MessageBox.Show("Group does not exist OR Incorrect Password.");}
						}
						else{
							MessageBox.Show("Group does not exist OR Incorrect Password.");
						}
				}else
				{
					MessageBox.Show("This Email Already Registered One Account.");
				}
			}else
			{
				MessageBox.Show("This username already exist."+System.Environment.NewLine+"Please try another.");
			}
			cnn.Close();
			}
			
		}
		public void incerter(String Group)
		{
			Random rnd = new Random();
			int random = rnd.Next(1, 1000);
			String code = random.ToString();
			String Username = username.Text;
			String Email = email.Text;
			try
			{String emailbody = "Your Account Details are :"+System.Environment.NewLine+" username : "+Username+""+System.Environment.NewLine+" Activation Code : "+code+"";
			MailMessage mail = new MailMessage("email", ""+Email+"", "Activation Code for Chatter32 Account", emailbody);
			SmtpClient client = new SmtpClient("smtp.gmail.com");
			client.Port = 587;	
			client.Credentials = new System.Net.NetworkCredential("email@gmail.com","yoyoyala0");
			client.EnableSsl = true;
			client.Send(mail);
			string connectionString = "Data Source=db4free.net;Initial Catalog=database;User ID=username;Password=password";
			MySqlConnection cnn = new MySqlConnection(connectionString);
			cnn.Open();
			MySqlCommand cmd1 = new MySqlCommand();
			cmd1.CommandText = "INSERT INTO `user`(`username`, `password`, `email`,`group`) VALUES ('"+Username+"','"+code+"','"+Email+"','"+Group+"');";
			cmd1.Connection = cnn;
			MySqlDataReader reader = cmd1.ExecuteReader();
			MessageBox.Show("Successfully Registered ! Sending Email.");
			MessageBox.Show("Email Send! Check mail for Activation Code.");
			}
			catch
			{
				MessageBox.Show("Invalid Email");
			}
			finally
			{
				username.Text="";
				email.Text="";
			}
		}
		void VeriClick(object sender, System.EventArgs e)
		{
			String Username = username1.Text;
			String Password = password.Text;
			String code = code1.Text;
			string connectionString = "Data Source=db4free.net;Initial Catalog=database;User ID=username;Password=password";
			MySqlConnection cnn = new MySqlConnection(connectionString);
			cnn.Open();
			MySqlCommand cmd = new MySqlCommand();
			MySqlCommand cmd0 = new MySqlCommand();
			MySqlCommand cmd1 = new MySqlCommand();
			cmd.CommandText = "select COALESCE(sum(ID),0) from user where username = '"+Username+"';";
			cmd0.CommandText="select password from user where username='"+Username+"'";
			cmd1.CommandText = "UPDATE `user` SET `password`='"+Password+"' WHERE username = '"+Username+"'";
			cmd.Connection = cnn;
			cmd1.Connection = cnn;
			cmd0.Connection = cnn;
			decimal detectcode = ((decimal)cmd.ExecuteScalar());
			if (detectcode !=0)
			{
				String detectpassword = (String)cmd0.ExecuteScalar().ToString();
				if(detectpassword==code)
				{
					cmd1.ExecuteScalar();
					MessageBox.Show("Password Inserted to the account." +
						System.Environment.NewLine +
						"Account Ready for use !");
					this.Close();
				}else
				{
					MessageBox.Show("Invalid Code !");
					username1.Text="";
					password.Text="";
				}
			}else
			{
				MessageBox.Show("Username doesn't exist.");
			}
		}
		void Button1Click(object sender, System.EventArgs e)
		{
			CreGroup gu = new CreGroup();
			gu.ShowDialog();
		}
	}
}
