﻿/*
 * Created by SharpDevelop.
 * User: Samarth
 * Date: 2014-04-28
 * Time: 10:27 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Chattter32
{
	partial class MainFor
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFor));
			this.Input = new System.Windows.Forms.TextBox();
			this.Out = new System.Windows.Forms.RichTextBox();
			this.Exit = new System.Windows.Forms.Button();
			this.Ent = new System.Windows.Forms.Button();
			this.name = new System.Windows.Forms.Label();
			this.refresh = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// Input
			// 
			this.Input.Location = new System.Drawing.Point(77, 27);
			this.Input.Name = "Input";
			this.Input.Size = new System.Drawing.Size(180, 20);
			this.Input.TabIndex = 0;
			// 
			// Out
			// 
			this.Out.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
			this.Out.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.Out.Location = new System.Drawing.Point(12, 53);
			this.Out.Name = "Out";
			this.Out.ReadOnly = true;
			this.Out.Size = new System.Drawing.Size(244, 154);
			this.Out.TabIndex = 1;
			this.Out.Text = "";
			// 
			// Exit
			// 
			this.Exit.BackColor = System.Drawing.Color.Red;
			this.Exit.Location = new System.Drawing.Point(3, 213);
			this.Exit.Name = "Exit";
			this.Exit.Size = new System.Drawing.Size(68, 36);
			this.Exit.TabIndex = 2;
			this.Exit.Text = "Exit";
			this.Exit.UseVisualStyleBackColor = false;
			this.Exit.Click += new System.EventHandler(this.ExitClick);
			// 
			// Ent
			// 
			this.Ent.BackColor = System.Drawing.Color.LimeGreen;
			this.Ent.Location = new System.Drawing.Point(177, 213);
			this.Ent.Name = "Ent";
			this.Ent.Size = new System.Drawing.Size(90, 35);
			this.Ent.TabIndex = 3;
			this.Ent.Text = "Enter";
			this.Ent.UseVisualStyleBackColor = false;
			this.Ent.Click += new System.EventHandler(this.EntClick);
			// 
			// name
			// 
			this.name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
			this.name.Location = new System.Drawing.Point(15, 30);
			this.name.Name = "name";
			this.name.Size = new System.Drawing.Size(56, 17);
			this.name.TabIndex = 4;
			this.name.Text = "name";
			// 
			// refresh
			// 
			this.refresh.BackColor = System.Drawing.Color.Yellow;
			this.refresh.ForeColor = System.Drawing.SystemColors.ControlText;
			this.refresh.Location = new System.Drawing.Point(84, 213);
			this.refresh.Name = "refresh";
			this.refresh.Size = new System.Drawing.Size(87, 35);
			this.refresh.TabIndex = 5;
			this.refresh.Text = "Refresh";
			this.refresh.UseVisualStyleBackColor = false;
			this.refresh.Click += new System.EventHandler(this.RefreshClick);
			// 
			// MainFor
			// 
			this.AcceptButton = this.Ent;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Highlight;
			this.ClientSize = new System.Drawing.Size(284, 261);
			this.Controls.Add(this.refresh);
			this.Controls.Add(this.name);
			this.Controls.Add(this.Ent);
			this.Controls.Add(this.Exit);
			this.Controls.Add(this.Out);
			this.Controls.Add(this.Input);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "MainFor";
			this.Text = "Chatter32";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button refresh;
		private System.Windows.Forms.TextBox Input;
		private System.Windows.Forms.RichTextBox Out;
		private System.Windows.Forms.Button Exit;
		private System.Windows.Forms.Button Ent;
		private System.Windows.Forms.Label name;

	}
}
