﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Chattter32
{
	public partial class Rem : Form
	{
		String connectionString = "Data Source=db4free.net;Initial Catalog=database;User ID=username;Password=password";
			MySqlConnection cnn;
			MySqlCommand cmd = new MySqlCommand();
		MySqlCommand cmd0 = new MySqlCommand();
			MySqlCommand cmd1 = new MySqlCommand();
		public Rem()
		{
			InitializeComponent();
			cnn = new MySqlConnection(connectionString);
			password.PasswordChar='*';
			cnn.Close();
		}
		void DeleteusClick(object sender, System.EventArgs e)
		{
			String Username = username.Text.ToString();
			String Password = password.Text.ToString();
			cnn.Close();
			try{cnn.Open();}catch{MessageBox.Show("Can not open connection ! Make Sure You Are Connected To Internet !"); cnn.Close();}
			cmd.CommandText = "select COALESCE(sum(ID),0) from user where username = '"+Username+"';";
			cmd0.CommandText="DELETE FROM `user` WHERE `username`='"+Username+"'";
			cmd1.CommandText = "Select password from user where username = '"+Username+"';";
			cmd.Connection = cnn;
			cmd0.Connection=cnn;
			cmd1.Connection = cnn;
			decimal total1 = ((decimal)cmd.ExecuteScalar());
			if(total1 != 0)
			{
				String dbpassword = ((String)cmd1.ExecuteScalar());
				if (dbpassword == Password)
				{
					cmd0.ExecuteScalar();
					MessageBox.Show("User Deleted Successfully!");
					this.Close();
				}else
				{
					MessageBox.Show("Incorrect Username OR Password !");
				}
			}else 
			{
				MessageBox.Show("Incorrect Username OR Password!");
			}
			cnn.Close();		
		}
	}
}
