﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Chattter32;

namespace Chattter32
{
	public partial class MainForm : Form
	{
			String connectionString = "Data Source=db4free.net;Initial Catalog=database;User ID=username;Password=password";
			MySqlConnection cnn;
			MySqlCommand cmd = new MySqlCommand();
		MySqlCommand cmd0 = new MySqlCommand();
			MySqlCommand cmd1 = new MySqlCommand();
		public MainForm()
		{
			InitializeComponent();
			password.PasswordChar='*';
			cnn = new MySqlConnection(connectionString);
			cnn.Close();
			//try
            //{
            //    cnn.Open();	
            //}
            //catch (Exception e)
            //{
            //	MessageBox.Show(e.ToString());//+"Can not open connection ! Make Sure You have Enough Internet Access!");
			//	Close();
            //}
            //finally
            //{
            //    cnn.Close();
            //}
			cnn.Close();
		}
		void LoginClick(object sender, System.EventArgs e)
		{
			String Username = username.Text.ToString();
			String Password = password.Text.ToString();
			cnn.Close();
			try{cnn.Open();}catch{MessageBox.Show("Can not open connection ! Make Sure You Are Connected To Internet !"); cnn.Close();}
			cmd.CommandText = "select COALESCE(sum(ID),0) from user where username = '"+Username+"';";
			cmd0.CommandText="SELECT `group` FROM `user` WHERE username='"+Username+"'";
			cmd1.CommandText = "Select password from user where username = '"+Username+"';";
			cmd.Connection = cnn;
			cmd0.Connection=cnn;
			cmd1.Connection = cnn;
			decimal total1 = ((decimal)cmd.ExecuteScalar());
			if(total1 != 0)
			{
				String dbpassword = ((String)cmd1.ExecuteScalar());
				if (dbpassword == Password)
				{
					this.Hide();
					MessageBox.Show("Login Successful!");
					String Group = (String)cmd0.ExecuteScalar();
					Chattter32.MainFor frm = new Chattter32.MainFor(this, Username,Group);
					frm.Show();
					
				}else
				{
					MessageBox.Show("Incorrect Username OR Password !");
				}
			}else 
			{
				MessageBox.Show("Incorrect Username OR Password!");
			}
			cnn.Close();		
		}
		void RegisterClick(object sender, System.EventArgs e)
		{
			MainFom frm2= new MainFom();
			frm2.ShowDialog();
		}
		void PasswordRecClick(object sender, System.EventArgs e)
		{
			PasswordRecovery frm3=new PasswordRecovery();
			frm3.ShowDialog();
		}
		void ChangeUserClick(object sender, System.EventArgs e)
		{
			Username2 s=new Username2();
			s.ShowDialog();
		}
		void ChangegClick(object sender, System.EventArgs e)
		{
			Rem rev =new Rem();
			rev.ShowDialog();
		}
		void Button1Click(object sender, System.EventArgs e)
		{
			Resend re=new Resend();
			re.ShowDialog();
		}
		void GlobalClick(object sender, System.EventArgs e)
		{
			String Username = username.Text.ToString();
			String Password = password.Text.ToString();
			cnn.Close();
			try{cnn.Open();}catch{MessageBox.Show("Can not open connection ! Make Sure You Are Connected To Internet !"); cnn.Close();}
			cmd.CommandText = "select COALESCE(sum(ID),0) from user where username = '"+Username+"';";
			cmd1.CommandText = "Select password from user where username = '"+Username+"';";
			cmd.Connection = cnn;
			cmd1.Connection = cnn;
			decimal total1 = ((decimal)cmd.ExecuteScalar());
			if(total1 != 0)
			{
				String dbpassword = ((String)cmd1.ExecuteScalar());
				if (dbpassword == Password)
				{
					this.Hide();
					MessageBox.Show("Global Login Successful!");
					Chattter32.MainFor frm = new Chattter32.MainFor(this, Username,"");
					frm.Show();
					
				}else
				{
					MessageBox.Show("Incorrect Username OR Password !");
				}
			}else 
			{
				MessageBox.Show("Incorrect Username OR Password!");
			}
			cnn.Close();
		}
		void Button2Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("This app was devloped and designed by Samarth Pusalkar..");
		}		
	}
}
