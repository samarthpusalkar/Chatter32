﻿using System;
using System.Net.Mail;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Chattter32
{
	public partial class Resend : Form
	{
		public Resend()
		{
			InitializeComponent();
		}
		void RegiClick(object sender, System.EventArgs e)
		{
			String Username = username.Text;
			String Email = email.Text;
			String username11 = Username.Replace(" ",string.Empty);
			String email11 = Email.Replace(" ",string.Empty);
			if(username11=="" || email11=="")
			{
				MessageBox.Show("Please Fill Both The Required Fields.");
			}else{
			string connectionString = "Data Source=db4free.net;Initial Catalog=database;User ID=username;Password=password";
			MySqlConnection cnn = new MySqlConnection(connectionString);
			try
            {
                cnn.Open();
					incerter();
					cnn.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Can not open connection ! Make Sure You Are Connected To Internet !");
				this.Close();
            }
            finally
            {
                cnn.Close();
            }
			cnn.Close();
			}
			
		}
		public void incerter()
		{
			Random rnd = new Random();
			int random = rnd.Next(1, 1000);
			String code = random.ToString();
			String Username = username.Text;
			String Email = email.Text;
			try
			{String emailbody = "Your Account Details are :"+System.Environment.NewLine+" username : "+Username+""+System.Environment.NewLine+" Activation Code : "+code+"";
			MailMessage mail = new MailMessage("email", ""+Email+"", "Activation Code for Chatter32 Account", emailbody);
			SmtpClient client = new SmtpClient("smtp.gmail.com");
			client.Port = 587;	
			client.Credentials = new System.Net.NetworkCredential("email@gmail.com","password");
			client.EnableSsl = true;
			string connectionString = "Data Source=db4free.net;Initial Catalog=chatter32;User ID=chating;Password=12332112";
			MySqlConnection cnn = new MySqlConnection(connectionString);
			cnn.Open();
			MySqlCommand cmd1 = new MySqlCommand();
				MySqlCommand cmd = new MySqlCommand();
			cmd1.CommandText = "UPDATE `user` SET `password`='"+code+"' WHERE username = '"+Username+"'";
				cmd.CommandText="Select email from user where username='"+Username+"'";
			cmd1.Connection = cnn;
				cmd.Connection=cnn;
				String Eemail=(String)cmd.ExecuteScalar().ToString();
				if(Email == Eemail){
			MySqlDataReader reader = cmd1.ExecuteReader();
			MessageBox.Show("Sending Email.");
					client.Send(mail);
					MessageBox.Show("Email Send! Check mail for Recovery Code.");
					cnn.Close();
					this.Close();
				}else
				{
					MessageBox.Show("Incorrect Email & Username combination !");
					cnn.Close();
				}
			}
			catch
			{
				MessageBox.Show("Invalid Email OR Username!" +
					"Or Check Internet connection.");
			}
			finally
			{
				username.Text="";
				email.Text="";
			}
		}
	}
}
