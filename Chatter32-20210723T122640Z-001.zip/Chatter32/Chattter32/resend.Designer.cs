﻿/*
 * Created by SharpDevelop.
 * User: Samarth
 * Date: 2014-05-01
 * Time: 5:02 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Chattter32
{
	partial class Resend
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Resend));
			this.email = new System.Windows.Forms.TextBox();
			this.username = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.regi = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// email
			// 
			this.email.Location = new System.Drawing.Point(111, 56);
			this.email.Name = "email";
			this.email.Size = new System.Drawing.Size(139, 20);
			this.email.TabIndex = 0;
			// 
			// username
			// 
			this.username.Location = new System.Drawing.Point(111, 107);
			this.username.Name = "username";
			this.username.Size = new System.Drawing.Size(138, 20);
			this.username.TabIndex = 1;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(23, 59);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(82, 17);
			this.label5.TabIndex = 2;
			this.label5.Text = "Email";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(21, 107);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(60, 37);
			this.label6.TabIndex = 3;
			this.label6.Text = "Username";
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(54, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(195, 34);
			this.label1.TabIndex = 4;
			this.label1.Text = "Resend Activation Code";
			// 
			// regi
			// 
			this.regi.Location = new System.Drawing.Point(54, 195);
			this.regi.Name = "regi";
			this.regi.Size = new System.Drawing.Size(157, 52);
			this.regi.TabIndex = 12;
			this.regi.Text = "Resend code";
			this.regi.UseVisualStyleBackColor = true;
			this.regi.Click += new System.EventHandler(this.RegiClick);
			// 
			// Resend
			// 
			this.AcceptButton = this.regi;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(284, 259);
			this.Controls.Add(this.regi);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.username);
			this.Controls.Add(this.email);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "Resend";
			this.Text = "Resend Code";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button regi;
		private System.Windows.Forms.TextBox email;
		private System.Windows.Forms.TextBox username;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label1;
	}
}
