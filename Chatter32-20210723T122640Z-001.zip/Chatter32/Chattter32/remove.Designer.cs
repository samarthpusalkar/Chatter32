﻿/*
 * Created by SharpDevelop.
 * User: Samarth
 * Date: 2014-05-05
 * Time: 11:41 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Chattter32
{
	partial class Rem
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rem));
			this.deleteus = new System.Windows.Forms.Button();
			this.username = new System.Windows.Forms.TextBox();
			this.password = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// deleteus
			// 
			this.deleteus.Location = new System.Drawing.Point(52, 145);
			this.deleteus.Name = "deleteus";
			this.deleteus.Size = new System.Drawing.Size(169, 58);
			this.deleteus.TabIndex = 0;
			this.deleteus.Text = "Delete User";
			this.deleteus.UseVisualStyleBackColor = true;
			this.deleteus.Click += new System.EventHandler(this.DeleteusClick);
			// 
			// username
			// 
			this.username.Location = new System.Drawing.Point(117, 22);
			this.username.Name = "username";
			this.username.Size = new System.Drawing.Size(143, 20);
			this.username.TabIndex = 1;
			// 
			// password
			// 
			this.password.Location = new System.Drawing.Point(117, 86);
			this.password.Name = "password";
			this.password.Size = new System.Drawing.Size(143, 20);
			this.password.TabIndex = 2;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(22, 25);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(77, 23);
			this.label1.TabIndex = 3;
			this.label1.Text = "Username";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(22, 86);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(77, 17);
			this.label2.TabIndex = 4;
			this.label2.Text = "Password";
			// 
			// Rem
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(284, 211);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.password);
			this.Controls.Add(this.username);
			this.Controls.Add(this.deleteus);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "Rem";
			this.Text = "Remove user";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button deleteus;
		private System.Windows.Forms.TextBox username;
		private System.Windows.Forms.TextBox password;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
	}
}
