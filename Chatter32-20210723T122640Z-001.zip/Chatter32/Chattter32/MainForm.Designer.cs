﻿/*
 * Created by SharpDevelop.
 * User: Samarth
 * Date: 2014-04-30
 * Time: 1:19 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Chattter32
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.username = new System.Windows.Forms.TextBox();
			this.password = new System.Windows.Forms.TextBox();
			this.register = new System.Windows.Forms.Button();
			this.login = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.passwordRec = new System.Windows.Forms.Button();
			this.ChangeUser = new System.Windows.Forms.Button();
			this.changeg = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.global = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// username
			// 
			this.username.Location = new System.Drawing.Point(118, 40);
			this.username.Name = "username";
			this.username.Size = new System.Drawing.Size(136, 20);
			this.username.TabIndex = 0;
			// 
			// password
			// 
			this.password.Location = new System.Drawing.Point(118, 95);
			this.password.Name = "password";
			this.password.Size = new System.Drawing.Size(136, 20);
			this.password.TabIndex = 1;
			// 
			// register
			// 
			this.register.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
			this.register.Location = new System.Drawing.Point(12, 159);
			this.register.Name = "register";
			this.register.Size = new System.Drawing.Size(80, 59);
			this.register.TabIndex = 2;
			this.register.Text = "Register";
			this.register.UseVisualStyleBackColor = false;
			this.register.Click += new System.EventHandler(this.RegisterClick);
			// 
			// login
			// 
			this.login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
			this.login.Location = new System.Drawing.Point(184, 159);
			this.login.Name = "login";
			this.login.Size = new System.Drawing.Size(88, 59);
			this.login.TabIndex = 4;
			this.login.Text = "Login";
			this.login.UseVisualStyleBackColor = false;
			this.login.Click += new System.EventHandler(this.LoginClick);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(37, 43);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(75, 22);
			this.label1.TabIndex = 5;
			this.label1.Text = "Username :";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(40, 98);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(72, 17);
			this.label2.TabIndex = 6;
			this.label2.Text = "Password  :";
			// 
			// passwordRec
			// 
			this.passwordRec.BackColor = System.Drawing.Color.IndianRed;
			this.passwordRec.Location = new System.Drawing.Point(12, 258);
			this.passwordRec.Name = "passwordRec";
			this.passwordRec.Size = new System.Drawing.Size(80, 49);
			this.passwordRec.TabIndex = 7;
			this.passwordRec.Text = "Forgot Password ?";
			this.passwordRec.UseVisualStyleBackColor = false;
			this.passwordRec.Click += new System.EventHandler(this.PasswordRecClick);
			// 
			// ChangeUser
			// 
			this.ChangeUser.BackColor = System.Drawing.Color.Green;
			this.ChangeUser.Location = new System.Drawing.Point(184, 258);
			this.ChangeUser.Name = "ChangeUser";
			this.ChangeUser.Size = new System.Drawing.Size(88, 49);
			this.ChangeUser.TabIndex = 8;
			this.ChangeUser.Text = "Change/Forgot Username ?";
			this.ChangeUser.UseVisualStyleBackColor = false;
			this.ChangeUser.Click += new System.EventHandler(this.ChangeUserClick);
			// 
			// changeg
			// 
			this.changeg.BackColor = System.Drawing.Color.Yellow;
			this.changeg.Location = new System.Drawing.Point(98, 258);
			this.changeg.Name = "changeg";
			this.changeg.Size = new System.Drawing.Size(80, 48);
			this.changeg.TabIndex = 9;
			this.changeg.Text = "Delete User";
			this.changeg.UseVisualStyleBackColor = false;
			this.changeg.Click += new System.EventHandler(this.ChangegClick);
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.button1.Location = new System.Drawing.Point(70, 221);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(134, 31);
			this.button1.TabIndex = 10;
			this.button1.Text = "Resend Activation code";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// global
			// 
			this.global.BackColor = System.Drawing.Color.MediumSpringGreen;
			this.global.Location = new System.Drawing.Point(98, 162);
			this.global.Name = "global";
			this.global.Size = new System.Drawing.Size(74, 53);
			this.global.TabIndex = 11;
			this.global.Text = "Global Chat";
			this.global.UseVisualStyleBackColor = false;
			this.global.Click += new System.EventHandler(this.GlobalClick);
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
			this.button2.Location = new System.Drawing.Point(80, 313);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(98, 41);
			this.button2.TabIndex = 12;
			this.button2.Text = "Credits";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// MainForm
			// 
			this.AcceptButton = this.login;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
			this.ClientSize = new System.Drawing.Size(284, 363);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.global);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.changeg);
			this.Controls.Add(this.ChangeUser);
			this.Controls.Add(this.passwordRec);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.login);
			this.Controls.Add(this.register);
			this.Controls.Add(this.password);
			this.Controls.Add(this.username);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.Text = "Login";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button global;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button changeg;
		private System.Windows.Forms.Button passwordRec;
		private System.Windows.Forms.Button ChangeUser;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox username;
		private System.Windows.Forms.TextBox password;
		private System.Windows.Forms.Button register;
		private System.Windows.Forms.Button login;
	}
}
