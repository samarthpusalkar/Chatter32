﻿/*
 * Created by SharpDevelop.
 * User: Samarth
 * Date: 2014-05-01
 * Time: 5:02 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Chattter32
{
	partial class Username2
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Username2));
			this.email = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.email1 = new System.Windows.Forms.TextBox();
			this.code1 = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.regi = new System.Windows.Forms.Button();
			this.veri = new System.Windows.Forms.Button();
			this.username = new System.Windows.Forms.TextBox();
			this.pa = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// email
			// 
			this.email.Location = new System.Drawing.Point(111, 56);
			this.email.Name = "email";
			this.email.Size = new System.Drawing.Size(139, 20);
			this.email.TabIndex = 0;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(23, 59);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(82, 17);
			this.label5.TabIndex = 2;
			this.label5.Text = "Email";
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(77, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(137, 22);
			this.label1.TabIndex = 4;
			this.label1.Text = "Reset Username";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(77, 36);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(54, 17);
			this.label2.TabIndex = 5;
			this.label2.Text = "Step 1";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(14, 153);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(266, 10);
			this.label3.TabIndex = 6;
			this.label3.Text = "---------------------------------------------------------------------------------" +
	"----";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(77, 172);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(54, 18);
			this.label4.TabIndex = 7;
			this.label4.Text = "Step 2";
			// 
			// email1
			// 
			this.email1.Location = new System.Drawing.Point(110, 193);
			this.email1.Name = "email1";
			this.email1.Size = new System.Drawing.Size(138, 20);
			this.email1.TabIndex = 8;
			// 
			// code1
			// 
			this.code1.Location = new System.Drawing.Point(110, 240);
			this.code1.Name = "code1";
			this.code1.Size = new System.Drawing.Size(138, 20);
			this.code1.TabIndex = 9;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(14, 195);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(67, 18);
			this.label7.TabIndex = 10;
			this.label7.Text = "Email  :";
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(14, 240);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(76, 30);
			this.label8.TabIndex = 11;
			this.label8.Text = "Reset Code :";
			// 
			// regi
			// 
			this.regi.Location = new System.Drawing.Point(77, 110);
			this.regi.Name = "regi";
			this.regi.Size = new System.Drawing.Size(160, 40);
			this.regi.TabIndex = 12;
			this.regi.Text = "Send Me My Code";
			this.regi.UseVisualStyleBackColor = true;
			this.regi.Click += new System.EventHandler(this.RegiClick);
			// 
			// veri
			// 
			this.veri.Location = new System.Drawing.Point(146, 337);
			this.veri.Name = "veri";
			this.veri.Size = new System.Drawing.Size(101, 43);
			this.veri.TabIndex = 13;
			this.veri.Text = "Change Username";
			this.veri.UseVisualStyleBackColor = true;
			this.veri.Click += new System.EventHandler(this.VeriClick);
			// 
			// username
			// 
			this.username.Location = new System.Drawing.Point(110, 291);
			this.username.Name = "username";
			this.username.Size = new System.Drawing.Size(137, 20);
			this.username.TabIndex = 14;
			// 
			// pa
			// 
			this.pa.Location = new System.Drawing.Point(14, 294);
			this.pa.Name = "pa";
			this.pa.Size = new System.Drawing.Size(91, 23);
			this.pa.TabIndex = 15;
			this.pa.Text = "New Username :";
			// 
			// Username2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(284, 392);
			this.Controls.Add(this.pa);
			this.Controls.Add(this.username);
			this.Controls.Add(this.veri);
			this.Controls.Add(this.regi);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.code1);
			this.Controls.Add(this.email1);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.email);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "Username2";
			this.Text = "Reset Username";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Label pa;
		private System.Windows.Forms.Button regi;
		private System.Windows.Forms.Button veri;
		private System.Windows.Forms.TextBox email;
		private System.Windows.Forms.TextBox username;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox email1;
		private System.Windows.Forms.TextBox code1;
	}
}
